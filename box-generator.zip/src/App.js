import React, { useState } from "react";
import { Boxes } from "./components/Boxes";

function App() {
  const [input, setInput] = useState("");
  const [colorList, setColorList] = useState([]);

  const handleTyping = (e) => {
    setInput(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setColorList([...colorList, input]);
    setInput("");
  };

  // console.log(colorList);
  return (
    <form className="app" onSubmit={handleSubmit}>
      <label htmlFor="color">Color</label>
      <input type="text" id="color" onChange={handleTyping} />
      <button type="submit">Add</button>
      <Boxes list={colorList} />
    </form>
  );
}

export default App;
