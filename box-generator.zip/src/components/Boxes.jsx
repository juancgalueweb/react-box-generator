import React from "react";

export const Boxes = ({ list }) => {
  return (
    <div className="container">
      {list.length > 0 &&
        list.map((ele, index) => (
          <div
            key={index}
            className="boxes"
            style={{ backgroundColor: ele }}
          ></div>
        ))}
    </div>
  );
};
